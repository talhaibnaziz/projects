
public class State {
	public int[] obj;
	public State()
	{
		obj = new int[4];
		obj[0] = obj[1] = obj[2] = obj[3] = 0;
	}
	public State(int wolf, int cabbage, int farmer, int goat) {
		obj = new int[4];
		obj[0] = wolf;
		obj[1] = cabbage;
		obj[2] = farmer;
		obj[3] = goat;
	}
	
	public State[] generateNextState()
	{
		State ret[] = new State[4];
		int idx = 0;
		
		State s1 = new State(obj[0], obj[1], obj[2], obj[3]);
		s1.obj[2] = (s1.obj[2] == 1 ? 0 : 1);
		ret[idx++] = s1;
		
		for (int i = 0; i<4; i++)
		{
			if (i == 2)
				continue;
			State s = new State(obj[0], obj[1], obj[2], obj[3]);
			s.obj[2] = (s.obj[2] == 1 ? 0 : 1);
			s.obj[i] = (s.obj[i] != s.obj[2] ? s.obj[2] : s.obj[i]);
			ret[idx++] = s;
		}
		return ret;
	}
	
	public boolean isIllegalState()
	{
		if (obj[0] == 0 && obj[2] == 1 && obj[3] == 0)
		{
			return true;
		}
		if (obj[0] == 1 && obj[2] == 0 && obj[3] == 1)
		{
			return true;
		}
		if (obj[1] == 1 && obj[2] == 0 && obj[3] == 1)
		{
			return true;
		}
		if (obj[1] == 0 && obj[2] == 1 && obj[3] == 0)
		{
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return "" + obj[0] + obj[1] + obj[2] + obj[3];
	}
	
}
